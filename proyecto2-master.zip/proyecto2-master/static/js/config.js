// API key para generar el mapa
const API_KEY = "pk.eyJ1Ijoic2FuY2luaW5lYSIsImEiOiJjazUzNW0za3YwNHpvM2t0N3MxNzJtM3lzIn0.pW-q43rBF-lAxRGwP1A8Wg";;